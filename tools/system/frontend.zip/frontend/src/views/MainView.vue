<template>

</template>

<script>
export default {
  inject: ['reload'],
  name: 'MainView',
  data () {
    return {
      image: 'data:image/jpeg;base64,' + localStorage.getItem('query'),
      dataset_type: localStorage.getItem('dataset_type')
    }
  },
  methods: {
  },
  mounted () {
    const query = localStorage.getItem('query')
    const imgList = Object.keys(localStorage.getItem('imgList'))
    document.getElementById('top1').setAttribute('src','data:image/jpeg;base64,'+localStorage.getItem('top1'))
  }
}
</script>

<style scoped>
.main1{
  height: 300px;
  margin-bottom: 15px;
  margin-right: 15px;
  /*overflow-y: hidden;*/
}
.main1 img{
  height: 300px;
}
.el-row {
  margin-bottom: 20px;
}
.el-col {
  border-radius: 4px;
}
.bg-purple-dark {
  background: #99a9bf;
}
.bg-purple {
  background: #d3dce6;
}
.bg-purple-light {
  background: #e5e9f2;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}
</style>
