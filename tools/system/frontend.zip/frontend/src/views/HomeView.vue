<template>
  <div class="box">
    <el-container>
      <el-header>
        <div class="header">
          <ul>
            <li>
              <el-select v-model="idx" placeholder="请选择">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </li>
            <li><span @click="display_prw">prw</span></li>
            <li><span @click="display_cuhk">CUHK</span></li>
            <li><span style="background-color: green;width: 200px">
              <el-input placeholder="请选择文件" v-model="textarea">
                <el-button
                  slot="append"
                  icon="el-icon-folder-opened"
                  @click="openFile"
                ></el-button>
              </el-input>
              <input
                type="file"
                name="filename"
                id="open"
                style="display: none"
                @change="changeFile"
              />
            </span></li>
          </ul>
        </div>
      </el-header>
      <el-container>
        <el-aside width="200px">
          <div class="aside">
            <el-menu>
              <el-menu-item @click="selectModel(1)">Search(SOTA)</el-menu-item>
              <el-menu-item @click="selectModel(2)">Search(Base)</el-menu-item>
            </el-menu>
          </div>
        </el-aside>
        <el-main>
          <div class="main">
            <div>
              <el-row>
                <el-col :span="12"><div class="main1 grid-content bg-purple">
                  <img id="top0" src="" alt="">
                </div></el-col>
                <el-col :span="12"><div class="main1 grid-content bg-purple-light">
                  <img id="top1" src="">
                </div></el-col>
                <el-col :span="12"><div class="main1 grid-content bg-purple">
                  <img id="top2"  src="">
                </div></el-col>
                <el-col :span="12"><div class="main1 grid-content bg-purple-light">
                  <img id="top3"  src="">
                </div></el-col>
                <el-col :span="12"><div class="main1 grid-content bg-purple">
                  <img id="top4"  src="">
                </div></el-col>
                <el-col :span="12"><div class="main1 grid-content bg-purple-light">
                  <img id="top5"  src="">
                </div></el-col>
              </el-row>
            </div>
          </div>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'HomeView',
  data () {
    return {
      model: ['Search(SOTA)', 'Search(Base)'],
      textarea: '',
      ifRouterAlive: true,
      CUHK: 1,
      idx: 1,
      base_url: this.$base_url,
      model_type: 1,
      isUpload: false,
      dataset_type: 0,
      options: [
        { value: '1', label: '1' },
        { value: '2', label: '2' },
        { value: '3', label: '3' },
        { value: '4', label: '4' },
        { value: '5', label: '5' },
        { value: '6', label: '6' },
        { value: '7', label: '7' },
        { value: '8', label: '8' },
        { value: '9', label: '9' },
        { value: '10', label: '10' }
      ]
    }
  },
  methods: {
    clearImg () {
      for (let i = 1; i <= 5; i++) {
        document.getElementById('top' + i).setAttribute('src', '')
      }
    },
    // eslint-disable-next-line camelcase
    queryMore (model_type, dataset_type, idx) {
      const _this = this
      _this.clearImg()
      if (_this.isUpload) {
        _this.idx = null
      }
      axios({
        url: _this.$base_url + '/search',
        method: 'post',
        data: {
          model_type: parseInt(model_type),
          dataset_type: parseInt(dataset_type),
          idx: parseInt(idx)
        }
      }).then(res => {
        const keys = Object.keys(res.data)
        let i = 0
        keys.forEach(item => {
          const doc = document.getElementById('top' + i++)
          if (doc !== null) {
            doc.setAttribute('src', 'data:image/jpeg;base64,' + res.data[item])
          }
        })
      })
    },
    openFile () {
      document.getElementById('open').click()
    },
    changeFile () {
      const fu = document.getElementById('open')
      if (fu == null) return
      this.textarea = fu.files[0].name
      this.imgUpload(fu.value)
    },
    imgUpload (imgUrl) {
      const _this = this
      const files = document.getElementById('open').files[0]
      const reader = new FileReader()
      reader.readAsDataURL(files)
      reader.onload = () => {
        // eslint-disable-next-line no-unused-vars
        const base64 = reader.result
        axios({
          url: _this.$base_url + '/upload_image',
          method: 'post',
          data: {
            image_encoder: base64
          }
        }).then(res => {
          _this.dataset_type = 2
          document.getElementById('top0').setAttribute('src', base64)
          _this.clearImg()
          _this.isUpload = true
        })
      }
      reader.onerror = function (error) {
        console.log('Error: ', error)
      }
    },
    selectModel (model) {
      const _this = this
      this.$message({
        message: '模块：' + _this.model[model - 1],
        type: 'success'
      })
      this.model_type = model
      _this.queryMore(parseInt(model), parseInt(_this.dataset_type), parseInt(_this.idx))
    },
    reload () {
      this.ifRouterAlive = false
      this.$nextTick(() => {
        this.ifRouterAlive = true
      })
    },
    async display_prw () {
      const _this = this
      _this.isUpload = false
      _this.clearImg()
      await axios({
        method: 'POST',
        url: _this.base_url + '/display_prw',
        headers: {
          'Content-Type': 'application/json'
        },
        data: {
          idx: parseInt(_this.idx)
        }
      }).then(res => {
        // const parseElement = JSON.parse(res.data)['data']
        document.getElementById('top0').setAttribute('src', 'data:image/jpeg;base64,' + res.data.image)
        _this.dataset_type = 0
        _this.reload()
      })
    },
    async display_cuhk () {
      const _this = this
      _this.isUpload = false
      _this.clearImg()
      await axios({
        method: 'POST',
        url: _this.base_url + '/display_cuhk',
        headers: {
          'Content-Type': 'application/json'
        },
        data: {
          idx: parseInt(_this.idx)
        }
      }).then(res => {
        document.getElementById('top0').setAttribute('src', 'data:image/jpeg;base64,' + res.data.image)
        _this.dataset_type = 1
        _this.reload()
      })
    }
  }
}
</script>

<style scoped>
.box{
  position: relative;
}
.aside{
  height: 94.5vh;
}
.header{
  text-align: left;
  /*height: 10vh;*/
}
.header ul{
  position:absolute ;
  left: 200px;
}
.header ul li{
  text-align: center;
  width: 100px;
  cursor: pointer;
  margin: 0 20px;
  display: inline-block;
  text-decoration: none;
}
.header span{
  display: block;
  height: 30px;
  line-height: 30px;
  border-radius: 5px;
  background-color: orange;
}
.aside ul li{
  color: white;
  font-size: 22px;
  background-color: deepskyblue;
}
.aside ul li:hover{
  background-color: aqua;
}
.header ul li:nth-child(1){
  margin-left: 0;
}
.main{
  height: 90vh;
}
.el-header, .el-footer {
  background-color: #B3C0D1;
  color: #333;
  text-align: center;
  line-height: 60px;
}

.el-aside {
  background-color: #D3DCE6;
  color: #333;
  text-align: center;
  line-height: 200px;
}

.el-main {
  background-color: #E9EEF3;
  color: #333;
  text-align: center;
  line-height: 160px;
}

body > .el-container {
  margin-bottom: 40px;
}

.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
  line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
  line-height: 320px;
}
.main1{
  height: 300px;
  margin-bottom: 15px;
  margin-right: 15px;
  /*overflow-y: hidden;*/
}
.main1 img{
  height: 300px;
}
.el-row {
  margin-bottom: 20px;
}
.el-col {
  border-radius: 4px;
}
.bg-purple-dark {
  background: #99a9bf;
}
.bg-purple {
  background: #d3dce6;
}
.bg-purple-light {
  background: #e5e9f2;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}
</style>
